import os  #Importig a library into your code

# print(os.system('df -h')) # for linux and MacOs
# print(os.system('uptime'))
# print(os.system('free -h')) # for linux
# print(os.system('systeminfo')) # for windows
# os.chdir(path)
# os.system('wmic logicaldisk get size,freespace,caption')

# os.system('ipconfig')
os.system('whoami')
os.system('date')





